export const INITIAL_DEBT = {
  id: 'debt-1',
  name: '',
  balance: 0,
  interestRate: 0,
  minimumPayment: 0,
  isStatic: false
};